# Distilled Lessons

Transferable insights from every kill/revise/scale decision. Later hypotheses inherit
these; check before designing any new experiment.

- (build) Tied embeddings need GPT-style N(0,0.02) init; PyTorch defaults produced
  ~10x inflated initial loss (58 vs 5.6) and would have silently wasted every early
  run. Caught by the CPU smoke test before any GPU time was spent.
- (build) nn.MultiheadAttention's fused path is invisible to FlopCounterMode; explicit
  attention matmuls are required for honest FLOP cross-checks.
- (build) Template text (family-fixed instruction headers) makes raw n-gram overlap
  audits useless; audit rare n-grams / near-duplicate coverage instead.
- (EXP-000) Multi-task dilution: 4000 steps over 7 families (~570/family) starves
  every family below learnability at 3-6M params; the same model on one family
  reaches 21.5% (probe 8bee22). Design all tiny experiments with >= ~2500 focused
  steps per family; validity-gate discrimination now runs per-family.
- (EXP-000) Full-sequence LM loss on template-heavy prompts converges 4L and 8L to
  identical loss while both fail the task; supervise the answer suffix only.
- (hardware) Sustained 100% GPU duty cycle hard-crashed the local box (PSU transient
  trip). All local runs now use the 25% duty-cycle throttle + 250W power cap
  (nvidia-smi -pl 250, needs admin, resets on reboot).
- (EXP-000 attempt 4) Mod-wrap arithmetic (3-7=96) is a distinct skill that floors
  3-6M models at ~10%; it gated algo_exec tier 3+ for BOTH depths. Difficulty knobs
  must never smuggle in an unrelated hard skill. Wrap ops now enter only at tier 5.
- (EXP-000 attempt 4) Gate criterion corrected BEFORE attempt 5 (pre-registered):
  depth separation required on all 3 computation families; memory families
  (rule_shift, compress) instead require a learnable headroom band — they are H2
  dissociation targets and expecting depth gains there contradicted our own H2
  design. Recorded here to make the criterion change auditable and non-cherry-picked.
- (EXP-000 attempt 4) An 8L model collapsed to degenerate repeats on rule_shift
  (train loss smooth, eval 0%) while 4L scored 100% — optimization instability at
  depth on easy saturated tasks. If it recurs: lower gate lr 6e-4 -> 4e-4.
